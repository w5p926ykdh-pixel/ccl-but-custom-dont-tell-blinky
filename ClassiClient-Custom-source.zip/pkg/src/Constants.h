#ifndef CC_CONSTANTS_H
#define CC_CONSTANTS_H
/* 
Defines useful constants
Copyright 2014-2025 ClassiCube | Licensed under BSD-3
*/

#define GAME_MAX_CMDARGS 5
#define GAME_APP_VER "1.0.1"

#if defined CC_BUILD_WEB
#define GAME_APP_ALT   "ClassiClient 1.0.2 web mobile"
#define GAME_APP_NAME  "ClassiClient 1.0.2 web"
#define GAME_APP_TITLE "ClassiClient"
#else
#define GAME_APP_NAME  "ClassiClient 1.0.2"
#define GAME_APP_TITLE "ClassiClient 1.0.2"
#endif

/* Max number of characters strings can have. */
#define STRING_SIZE 64
/* Max number of characters filenames can have. */
#define FILENAME_SIZE 260

/* Chunk axis length in blocks. */
#define CHUNK_SIZE 16
#define HALF_CHUNK_SIZE 8
#define CHUNK_SIZE_2 (CHUNK_SIZE * CHUNK_SIZE)
#define CHUNK_SIZE_3 (CHUNK_SIZE * CHUNK_SIZE * CHUNK_SIZE)

#define CHUNK_MAX 15
/* Local index in a chunk for a coordinate. */
#define CHUNK_MASK 15
/* Chunk index for a coordinate. */
#define CHUNK_SHIFT 4

/* Chunk axis length (plus neighbours) in blocks. */
#define EXTCHUNK_SIZE 18
#define EXTCHUNK_SIZE_2 (EXTCHUNK_SIZE * EXTCHUNK_SIZE)
#define EXTCHUNK_SIZE_3 (EXTCHUNK_SIZE * EXTCHUNK_SIZE * EXTCHUNK_SIZE)

/* Minor adjustment to max UV coords, to avoid pixel bleeding errors due to rounding. */
#define UV2_Scale (15.99f / 16.0f)

#define GAME_DEF_TICKS (1.0 / 20)
#define GAME_NET_TICKS (1.0 / 60)

#define GUI_MAX_CHATLINES 30

#define FACE_XMIN  0 /* Face X = 0 */
#define FACE_XMAX  1 /* Face X = 1 */
#define FACE_ZMIN  2 /* Face Z = 0 */
#define FACE_ZMAX  3 /* Face Z = 1 */
#define FACE_YMIN  4 /* Face Y = 0 */
#define FACE_YMAX  5 /* Face Y = 1 */
#define FACE_COUNT 6 /* Number of faces on a cube */

#define FACE_BIT_XMIN (1 << FACE_XMIN)
#define FACE_BIT_XMAX (1 << FACE_XMAX)
#define FACE_BIT_ZMIN (1 << FACE_ZMIN)
#define FACE_BIT_ZMAX (1 << FACE_ZMAX)
#define FACE_BIT_YMIN (1 << FACE_YMIN) 
#define FACE_BIT_YMAX (1 << FACE_YMAX)

enum SKIN_TYPE { SKIN_64x32, SKIN_64x64, SKIN_64x64_SLIM, SKIN_INVALID = 0xF0 };
#define DRAWER2D_MAX_COLORS 256

#define UInt8_MaxValue  ((cc_uint8)255)
#define Int16_MaxValue  ((cc_int16)32767)
#define UInt16_MaxValue ((cc_uint16)65535)
#define Int32_MinValue  ((cc_int32)-2147483647L - (cc_int32)1L)
#define Int32_MaxValue  ((cc_int32)2147483647L)

#define SKINS_SERVER    "https://classiclient.dedyn.io/skin"
#define UPDATES_SERVER  ""
#define SERVICES_SERVER "https://classiclient.dedyn.io/api"
#define RESOURCE_SERVER "http://static.classicube.net"
/* Webpage where users can register for a new account */
#define REGISTERNEW_URL "https://classiclient.dedyn.io/register"

#define DEFAULT_USERNAME "Singleplayer"
#endif
